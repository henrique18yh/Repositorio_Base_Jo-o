from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

options = Options()
options.headless = False  

navegador = webdriver.Chrome(options=options)
navegador.get("https://docs.google.com/forms/d/e/1FAIpQLSe1kM6GuDUR34BcH88YdKuiCcjCQVevFWhElbNLtsoBHGob2A/viewform")

time.sleep(3)  # Espera a página carregar

campos = navegador.find_elements(By.CLASS_NAME, "whsOnd")  # Localiza todos os campos de texto

campos[0].send_keys("João")  # Nome
campos[1].send_keys("joaohenrique@email.com")  # Email válido

time.sleep(4)  # Espera os resultados carregarem  

botao_enviar = navegador.find_element(By.XPATH, "//span[text()='Enviar']")
botao_enviar.click()  # Envia o formulário

time.sleep(5)  # Espera a página carregar
navegador.quit()  # Fecha o navegador