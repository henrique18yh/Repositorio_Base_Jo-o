import requests #importa a biblioteca requests para fazer requisições HTTP

response = requests.get("http://172.25.253.124:5000/alunos") 

print(response.status_code) #imprime o código de status da resposta HTTP
print(response.text)

dados = {"nome": "João", "email": "'isaac@gmail.com "}

response = requests.post("http://172.25.253.124:5000/alunos", json=dados)

print(response.json())