import pyautogui
import time
time.sleep(2)
pyautogui.press("win")
time.sleep(3)
pyautogui.click(771,1052)
pyautogui.write("chrome")
pyautogui.sleep(2)
pyautogui.press("enter")
pyautogui.sleep(3)
pyautogui.click(939,33)
pyautogui.write("https://www.youtube.com")
pyautogui.sleep(3)
pyautogui.press("enter")
pyautogui.click(742,111)
pyautogui.sleep(3)
pyautogui.write("Python programacao")
pyautogui.press("enter")



