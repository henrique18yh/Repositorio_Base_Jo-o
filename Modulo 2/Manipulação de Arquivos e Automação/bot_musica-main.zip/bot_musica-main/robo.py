from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import time

# Configurações do navegador
options = Options()
options.headless = False  # Coloque True se quiser rodar "escondido"

# Inicia o navegador
navegador = webdriver.Chrome(options=options)

# Abre o YouTube
navegador.get("https://www.youtube.com")


# Espera a página carregar
time.sleep(3)

# Encontra o campo de busca
campo_busca = navegador.find_element(By.NAME, "search_query")

# Pesquisa o que quiser (altere aqui)
tema = "toturial de python"
campo_busca.send_keys(tema)
campo_busca.send_keys(Keys.ENTER)

# Espera os resultados carregarem
time.sleep(4)

# Pega os títulos dos vídeos
titulos = navegador.find_elements(By.ID, "video-title")

# Mostra os 5 primeiros títulos
print(f"\n🎧 Resultados para: {tema}\n")
for i in range(5):
    print(f"{i+1}. {titulos[i].text}")

# Fecha o navegador

time.sleep(3600)