import sqlite3 

conexao = sqlite3.connect("ricardaofather.db")

cursor = conexao.cursor()

cursor.execute("DELETE FROM funcionarios WHERE departamento = 'Marketing'")
cursor.fetchall()

conexao.commit()
print("Funcionário deletado com sucesso.")





