import sqlite3 

conexao = sqlite3.connect("ricardaofather.db")

cursor = conexao.cursor()

cursor.execute("UPDATE funcionarios SET cargo = 'Analista' WHERE id = 23")

cursor.fetchall()

conexao.commit()
print("Cargo atualizado com sucesso.")








