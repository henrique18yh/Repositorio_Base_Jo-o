import sqlite3 

conexao = sqlite3.connect("ricardaofather.db")

cursor = conexao.cursor()

cursor.execute("UPDATE funcionarios SET departamento = 'RH' WHERE pnome = 'Ana'")

cursor.fetchall()

conexao.commit()
print("Departamento atualizado com sucesso.")






