import sqlite3 

conexao = sqlite3.connect("ricardaofather.db")

cursor = conexao.cursor()

cursor.execute("UPDATE funcionarios SET telefone = '11 98888-7777' WHERE cpf = 15967994960")

cursor.fetchall()

conexao.commit()
print("Telefone atualizado com sucesso.")





























