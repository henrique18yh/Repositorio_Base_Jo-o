import sqlite3 

conexao = sqlite3.connect("ricardaofather.db")

cursor = conexao.cursor()
cursor.execute("UPDATE funcionarios SET salario = salario * 1.10 WHERE departamento = 'TI'")


conexao.commit()
print("Salário atualizado com sucesso.")


