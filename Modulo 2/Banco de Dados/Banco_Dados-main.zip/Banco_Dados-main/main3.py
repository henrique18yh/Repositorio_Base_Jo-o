import sqlite3
banco = sqlite3.connect('hospital.db')
cursor = banco.cursor()
cursor.execute("SELECT nome, medico_responsavel FROM pacientes WHERE medico_responsavel ='Dr. João'")
print(cursor.fetchall())
