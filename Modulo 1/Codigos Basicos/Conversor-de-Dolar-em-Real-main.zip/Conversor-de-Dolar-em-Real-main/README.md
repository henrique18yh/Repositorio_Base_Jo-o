<h1>🦾Conversor de Dólar para Real</h1>

<h2>Este projeto é um simples conversor de moeda que transforma valores em dólar (USD) para real brasileiro (BRL).</h2>

<h1> 🤖Funcionalidades</h1>

Converte um valor em dólar para real com base na cotação atual ou uma cotação fixa definida no código.

Fácil de usar e entender.

Pode ser adaptado para outras moedas.
