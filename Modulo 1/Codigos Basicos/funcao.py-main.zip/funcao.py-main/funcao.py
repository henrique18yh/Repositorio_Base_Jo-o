def registro(): 
    nome = input("digite seu nome: ")

    idade = int(input("digite sua idade: "))

    if idade >= 18:
     print(f"acesso liberado {nome}")  
    else:
     print(f"acesso negado {nome}")
registro()