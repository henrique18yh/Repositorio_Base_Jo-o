# calculadora-média-dia
Este projeto foi criado com a seguinte tecnologia

- Python

Visa ajudar a realizar um calculo da média do aluno, onde você pode pode colocar 3 notas e a média calculará automaticamnete
