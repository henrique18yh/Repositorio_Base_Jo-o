peso = float(input("digite seu peso: "))
altura = float(input("digite a sua altura: "))

imc = peso / (altura * altura)

print(f"seu imc é: {imc}")