print("Boa tarde Alunos") = #Print mostra na tela.
input("") = #Coloca um valor inputado.
variavel = #Se declara com "=" e salva um valor dentro dela
str = #string e ela sempre sempre sempre vem entre "".
int = #inteiro, numeros inteiros (Que nao contem virgulas) = 1
float = #reais, numeros que contem virgula = 1.5
bool = #boleeano, Verdadeiro ou falso (True or False)
#\n = #Pula linha

#Operações aritméticas.
#Adição +
#Subtração -
#Multiplicação *
#Divisão / 

#Sinais
#Maior >
#Menor <
#Igual =
#Diferente !=
#Maior igual >=
#Menor igual <=