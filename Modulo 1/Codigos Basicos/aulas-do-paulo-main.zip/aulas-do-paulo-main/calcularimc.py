nome = input("digite seu nome: ")
altura = float(input("digite sua altra: "))
peso = float(input("dfigite seu peso: "))
             
imc = peso / (altura * altura)

if imc < 18.5:
   print("abaixo do peso")
elif imc >= 18.5 and imc <= 24.9:
   print("peso normal")
elif imc >= 25 and imc <= 29.9:
   print("acima do peso")
elif imc >= 30 and imc <= 34.9:
   print("obeso grau I ")
elif imc >= 35 and imc <= 39.9:
   print("obesidade grau II")
else :
   print("obesidade grau III")

print(f"o cliente {nome}, tem um imc de {imc}")
