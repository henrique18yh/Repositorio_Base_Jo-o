a = int(input("digite o primeiro numero: "))
b = int(input("digite o segundo numero: "))

c = a + b

print(c)