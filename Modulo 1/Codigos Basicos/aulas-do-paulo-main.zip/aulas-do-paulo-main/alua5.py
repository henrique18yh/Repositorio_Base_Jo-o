média1 = input("digite o nome do aluno: ") #este codigo calcula o 1°aluno

nota1 = float(input("didgite a primeira nota" )) #coloquei a nota 1
nota2 = float(input("digite a segunda nota")) #coloquei a nota 2
nota3 = float(input("digite a terceira nota")) #coloquei a nota 3
média = (nota1 + nota2 + nota3) / 3 #aqui eu coloquei a soma da conta
print(f"a media do aluno é: {média:.5f} ") #e aqui eu coloquei o tanto de casa da virgula

if media >= 7:
    print("APROVADO")
else:
     print("REPROVADO :(")

#f significa para eu conseguir um variavel entre aspas ""
#
    
















#adição +
#substração -
#divisão /
#multiplicação *
# <menor =
# maior> =

#if = SE
#else senão