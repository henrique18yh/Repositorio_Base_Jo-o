valor_total = float(input("Digite o valor total: "))
porcentagem = float(input("Digite o valor da porcentagem"))

valor_parte = valor_total * (porcentagem / 100)

print(f"A porcentagem de {porcentagem}% de {valor_total} é: {valor_parte}")