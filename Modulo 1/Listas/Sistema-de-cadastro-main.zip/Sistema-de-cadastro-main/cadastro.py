def cadastrar_nome(cadastro):
    novo_nome = input("Digite o nome da Pessoa: ")
    cadastro.append(novo_nome)
    print(f"Usuário {novo_nome} foi adicionado com sucesso!")

def listar_nomes(cadastro):
    print("\nLista de nomes cadastrados: ")
    for i, nome in enumerate (cadastro, start=1):
        print(f"{i}. {nome}")

def excluir_nomes(cadastro):
    excluir_nome = input("Dgote o nome para excluir: ")
    if excluir_nome in cadastro:
        cadastro.remove(excluir_nome)
        print(f"{excluir_nome} foi removido.")
    else:   
        print("Nome não encontrado.")
    
def menu():
    cadastro = []
    while True:
        print("\n---------Cadastro de funciomarios-----------")
        print("[1] Cadastrar Pessoa")
        print("[2] listar Pessoa")
        print("[3] Excluir Pessoa")
        print("[0] ")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
           cadastrar_nome(cadastro)
        elif opcao == '2':
            listar_nomes(cadastro)
        elif opcao == '3':
            excluir_nomes(cadastro)
        elif opcao == '0':
            print("Saindo...")
            break
        else:
            print("!!! Opção inválida. Tente novamente !!!")
menu()