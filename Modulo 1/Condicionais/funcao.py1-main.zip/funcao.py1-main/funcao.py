import json
ARQUIVO = "dados.json"

with open(ARQUIVO, "a+") as arquivo:
    arquivo.seek(0)
    try:
        json.load(arquivo)
    except:
        arquivo.write("[]")

def carregar():


    with open(ARQUIVO, "r") as arquivo:
        return json.load(arquivo)
def salvar(dados):
    with open(ARQUIVO, "w") as arquivo:
        json.dump(dados, arquivo)

def criar():
    nome = input("Nome: ")
    idade = input("Idade: ")
    email = input("Email: ")
    tel = input("Telefone: ")

    dados = carregar()
    dados.append({"nome": nome, "idade": idade, "email": email, "telefone": tel})
    salvar(dados)
    print("Salvo!")


def listar():
    dados = carregar()
    for p in dados:
        print(p)


    print("Nome não encontrado.")

def carregar():
    with open(ARQUIVO, "r") as arquivo:
        return json.load(arquivo)
   
def salvar(dados):
    with open(ARQUIVO, "w") as arquivo:
        json.dump(dados, arquivo)

def atualizar():
    nome = input("Nome para atualizar: ")
    dados = carregar()
    for linha in dados:
        if linha["nome"] == nome:
            linha["idade"] = input("Nova idade: ")
            linha["email"] = input("Novo email: ")
            linha["telefone"] = input("Novo telefone: ")
            salvar(dados)
            print("Atualizado!")
            return
    print("Nome não encontrado.")


def salvar(dados):
    with open(ARQUIVO, "w") as arquivo:
        json.dump(dados, arquivo)


def deletar():
    nome = input("Nome para deletar: ")
    dados = carregar()
    for linha in dados:
        if linha["nome"] == nome:
            dados.remove(linha)
            salvar(dados)
            print("\n\n ❌ Deletado! \n\n")
            return
    print("Nome não encontrado.")


def menu():
    pass
opcao = 0 
while opcao !=5:
    print("\n1 - Criar")
    print("2 - Listar")
    print("3 - Atualizar")
    print("4 - Deletar")
    print("5 - Sair")
    opcao = int(input("Escolha: "))
    if opcao == 1:
        criar()
    elif opcao == 2:
        listar()
    elif opcao == 3:
        atualizar()
    elif opcao == 4:
        deletar()
    elif opcao == 5:
            break

menu()