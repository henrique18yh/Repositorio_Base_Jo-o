numero = int(input("Digite seu numero: "))

valor = int(input("Digite um numero em qual você quer parar, lembre-se de digitar sempre um numero a mais ! :"))
i = int(input("Digite um numero que você quer começar: "))


for i in range(i, valor+1 ):
    print(f" {i} x {numero} = {i* numero}")