numero = int(input("Digite seu numero: "))

valor = int(input("Digite um numero em qual você quer parar :"))
i = int(input("Digite um numero que você quer começar: "))

while i <= (valor):
    print(f" {i} x {numero} = {i * numero}")

    i += 1