total_participantes = 0
maior_participantes = 0

#  Loop para pedir o número de participantes 5 vezes
for dia in range(1, 6):
    participantes_dia = int(input(f"Digite o número de participantes no dia {dia}: "))
    print(f"Dia {dia} total de participantes {participantes_dia}: ")
    #  Acumula o total de participantes
    total_participantes += participantes_dia
    print(total_participantes)

    if participantes_dia > maior_participantes:
        maior_participantes = participantes_dia
        print(f" o maior numero de participantes em um unico dia é:{maior_participantes}")
        print(f" á maior parte media do dia é: {total_participantes / 5}")