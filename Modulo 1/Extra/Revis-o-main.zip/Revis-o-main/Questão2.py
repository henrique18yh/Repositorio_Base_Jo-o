nome = input("NOME DO USARIO: ")
energia = int(input("digite seu nivel de energia: "))

if energia <= 19:
    print(" você esta exausto ")
elif energia <= 39:
    print("você esta cansado")
elif energia <= 59:
    print("você esta neutro")
elif energia <= 79:
    print("você esta animado")
elif energia <= 100:
    print("você esta eufórico")
else :
    print("energia invalida")