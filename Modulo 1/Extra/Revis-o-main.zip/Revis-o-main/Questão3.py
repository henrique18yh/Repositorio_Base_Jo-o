nome = input("didgite seu nome: ")
nota_final = float(input("digite sua nota final: "))

if nota_final >= 9.0 and nota_final <= 10.0:
   print("excelente")
if nota_final >= 7.0 and nota_final >= 8.9:
   print("bom")
if nota_final >= 5.0 and nota_final >=6.9:
   print("regular")
if nota_final >= 3.0 and nota_final >=4.9:
   print("critico")
else :
   print("nota inválida")

print(f"agente {nome} sua classificação é: {nota_final} ")