import os

#os.mkdir("Projetos")
print("Pasta criada!")

#os.rmdir("NovaPasta")
print("Pasta removida!")
 
os.rename("Projetos/arquivo.txt", "Projetos/xablau.txt")

# 4. Cria e escreve no arquivo
with open(nome,"w") as arquivo:
    arquivo.write("Esse é um arquivo criado dentro de uma pasta.")


for i in range(1, 2):
    nome = f"Projetos/ciencia.txt{i}.txt"
    with open(nome, "w") as arq:
        arq.write("Conteúdo gerado por Python\n")
    print(f"{nome} criado")  

arquivos = os.listdir()
for item in arquivos:
    print(item)